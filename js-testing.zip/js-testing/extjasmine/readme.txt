ExtJS demo page - http://localhost:8080/extjasminejstestdriver/simple.html
Jasmine demo page - http://localhost:8080/extjasminejstestdriver/run-tests.html