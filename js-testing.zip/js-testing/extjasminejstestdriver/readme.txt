ExtJS demo page - http://localhost:8080/extjasminejstestdriver/simple.html
Jasmine demo page - http://localhost:8080/extjasminejstestdriver/run-tests.html

JsTestDriver
------------
Install JsTestDriver (see jstestdriver-eclipse-plugin directory)
Create a JsTestDriver "Run Configuration" for jsTestDriver.conf
Open the JsTestDriver Eclipse view
Start the JsTestDriver server (play button)
Capture one or more browsers (click the browser icons)
Execute the JsTestDriver "Run Configuration"
(IE throws errors)