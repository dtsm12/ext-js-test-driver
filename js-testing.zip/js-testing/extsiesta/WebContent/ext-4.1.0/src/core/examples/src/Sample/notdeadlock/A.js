Ext.define('Sample.notdeadlock.A', {
    extend: 'Sample.notdeadlock.B'
});