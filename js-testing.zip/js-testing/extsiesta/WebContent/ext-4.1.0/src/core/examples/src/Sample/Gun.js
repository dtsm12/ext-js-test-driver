Ext.define('Sample.Gun', {
    
});