Ext.define('Sample.notdeadlock.B', {
    extend: 'Sample.notdeadlock.C',
    uses: 'Sample.notdeadlock.A'
});
