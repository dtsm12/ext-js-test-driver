Ext.Loader.setPath('extjstestdriver', '/test/app');
Ext.Loader.setPath('test', '/test/app-test');
Ext.Loader.setPath('Ext', '/test/ext/src');
Ext.Loader.setConfig({ enabled: true, syncModeEnabled: true });