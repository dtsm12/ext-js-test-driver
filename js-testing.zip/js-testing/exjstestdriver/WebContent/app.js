Ext.require('app.Application');
Ext.onReady(function() {new app.Application();});